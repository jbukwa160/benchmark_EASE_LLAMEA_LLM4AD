# Minimal pymoo.operators package.
