# Minimal pymoo shim.
